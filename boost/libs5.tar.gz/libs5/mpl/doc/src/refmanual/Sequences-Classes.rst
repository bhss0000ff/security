
The MPL provides a large number of predefined general-purpose sequence 
classes covering most of the typical metaprogramming needs out-of-box.

.. For all library-supplied sequences a publicly-derived class with no additional 
   members is equivalent except for type identity.


.. copyright:: Copyright �  2001-2009 Aleksey Gurtovoy and David Abrahams
   Distributed under the Boost Software License, Version 1.0. (See accompanying
   file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
