// Copyright Daniel Wallin 2005.
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_PARAMETER_FOR_EACH_051217_HPP
#define BOOST_PARAMETER_FOR_EACH_051217_HPP

#include <boost/parameter/aux_/preprocessor/impl/for_each.hpp>

#endif  // include guard

