# Boost.JSON Benchmarks

To run the benchmarks first run clone.sh to
fetch the third party repositories. Then run
the bench program with no arguments for a
list of command line options.

The benchmarked files were sourced from the
[simdjson](https://github.com/simdjson/simdjson) repository.
