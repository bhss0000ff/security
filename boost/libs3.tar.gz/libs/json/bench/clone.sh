mkdir -p lib
cd lib
git clone --depth 1 https://github.com/Tencent/rapidjson.git rapidjson
git clone --depth 1 https://github.com/nlohmann/json.git nlohmann
