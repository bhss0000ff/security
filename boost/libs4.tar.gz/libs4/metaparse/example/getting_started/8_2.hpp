#ifndef BOOST_METAPARSE_GETTING_STARTED_8_2_HPP
#define BOOST_METAPARSE_GETTING_STARTED_8_2_HPP

// Automatically generated header file

// Definitions before section 8.1
#include "8_1.hpp"

// Definitions of section 8.1

#endif

