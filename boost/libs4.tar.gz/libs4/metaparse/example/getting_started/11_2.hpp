#ifndef BOOST_METAPARSE_GETTING_STARTED_11_2_HPP
#define BOOST_METAPARSE_GETTING_STARTED_11_2_HPP

// Automatically generated header file

// Definitions before section 11.1
#include "11_1.hpp"

// Definitions of section 11.1

#endif

