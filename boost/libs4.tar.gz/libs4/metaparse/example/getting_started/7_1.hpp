#ifndef BOOST_METAPARSE_GETTING_STARTED_7_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_7_1_HPP

// Automatically generated header file

// Definitions before section 7
#include "7.hpp"

// Definitions of section 7

#endif

