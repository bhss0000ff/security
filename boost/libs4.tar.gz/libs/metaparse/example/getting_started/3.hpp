#ifndef BOOST_METAPARSE_GETTING_STARTED_3_HPP
#define BOOST_METAPARSE_GETTING_STARTED_3_HPP

// Automatically generated header file

// Definitions before section 2
#include "2.hpp"

// Definitions of section 2
#include <boost/metaparse/string.hpp>

// query:
//    boost::metaparse::string<'1', '1', ' ', '+', ' ', '2'>

// query:
//    BOOST_METAPARSE_STRING("11 + 2")

#endif

