#ifndef BOOST_METAPARSE_GETTING_STARTED_1_2_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_1_2_1_HPP

// Automatically generated header file

// Definitions before section 1.2
#include "1_2.hpp"

// Definitions of section 1.2

#endif

