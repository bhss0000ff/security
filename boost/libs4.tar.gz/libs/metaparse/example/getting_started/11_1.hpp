#ifndef BOOST_METAPARSE_GETTING_STARTED_11_1_HPP
#define BOOST_METAPARSE_GETTING_STARTED_11_1_HPP

// Automatically generated header file

// Definitions before section 11
#include "11.hpp"

// Definitions of section 11
// query:
//    exp_parser19::apply<BOOST_METAPARSE_STRING("hello")>::type

#endif

